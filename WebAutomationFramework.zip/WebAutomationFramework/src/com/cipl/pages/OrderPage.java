package com.cipl.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.cipl.driver.TestBase;

public class OrderPage extends TestBase {

	public OrderPage() {
		PageFactory.initElements(getDriver(), this);
	}

	@FindBy(id = "logout")
	private WebElement btnJoinUser;

	@FindBy(xpath = "//a[@rel='home']")
	private WebElement imgSitLogo;

	@FindBy(id = "small-map-desktop")
	private WebElement SmallMap;

	@FindBy(xpath = "//input[@id='Email']")
	private WebElement txtLogin;

	@FindBy(xpath = "//input[@id='Password']")
	private WebElement txtPassword;

	@FindBy(xpath = "//button[@id='Login_Btn']")
	private WebElement btnLogin;

	@FindBy(xpath = "//a[@id='NavMenu']")
	private WebElement btnMenu;

	@FindBy(xpath = "(//div[@class='product']//a[contains(@class,'ajax_add_to_cart')])[1]")
	private WebElement desiredProduct;

	@FindBy(xpath = "//button[@id='SingleItemOrder']")
	private WebElement btnAddItemToBag;

	@FindBy(xpath = "//a[@class='cart' and @href='/Home/Menu/The-Hog']")
	private WebElement btnCart;

	@FindBy(id = "btncheckout")
	private WebElement btncheckout;

	@FindBy(xpath = "//label[@for='pickup']")
	private WebElement rbnPickUp;

	@FindBy(id = "credit_card_holder_name")
	private WebElement txtCardHolderName;

	@FindBy(id = "credit_card_number")
	private WebElement txtCreditcardNumber;

	@FindBy(id = "expiry_date")
	private WebElement txtExpiryDate;

	@FindBy(id = "cvv")
	private WebElement txtCvv;

	@FindBy(id = "zipcode")
	private WebElement txtzipcode;

	@FindBy(id = "Submit")
	private WebElement btnPlaceOrder;

	@FindBy(xpath = "//div[@class='order-number-info']")
	private WebElement lblOrderNumberInfo;

	public WebElement getbtnJoinUser() {
		return btnJoinUser;
	}

	public WebElement getimgSiteLogo() {
		return imgSitLogo;
	}

	public WebElement getSmallMap() {
		return SmallMap;
	}

	public WebElement gettxtLogin() {
		return txtLogin;
	}

	public WebElement gettxtPassword() {
		return txtPassword;
	}

	public WebElement getbtnLogin() {
		return btnLogin;
	}

	public WebElement getbtnMenu() {
		return btnMenu;
	}

	public WebElement getDesiredProduct() {
		return desiredProduct;
	}

	public WebElement getbtnAddItemToBag() {
		return btnAddItemToBag;
	}

	public WebElement getbtnCart() {
		return btnCart;
	}

	public WebElement getbtncheckout() {
		return btncheckout;
	}

	public WebElement getrbnPickUp() {
		return rbnPickUp;
	}

	public WebElement gettxtCardHolderName() {
		return txtCardHolderName;
	}

	public WebElement gettxtCreditcardNumber() {
		return txtCreditcardNumber;
	}

	public WebElement gettxtExpiryDate() {
		return txtExpiryDate;
	}

	public WebElement gettxtCvv() {
		return txtCvv;
	}

	public WebElement gettxtzipcode() {
		return txtzipcode;
	}

	public WebElement getbtnPlaceOrder() {
		return btnPlaceOrder;
	}

	public WebElement getlblOrderNumberInfo() {
		return lblOrderNumberInfo;
	}

	public void doLogin(String strUserName, String strPassword) {
		WaitForElementPresent(gettxtLogin());
		gettxtLogin().sendKeys(strUserName);
		gettxtPassword().sendKeys(strPassword);
		getbtnLogin().click();
		WaitForElementPresent(getbtnMenu());
	}

	public void placeOrder() {
		getbtnMenu().click();
		WaitForElementPresent(getDesiredProduct());
		getDesiredProduct().click();

		WaitForElementClickable(getbtnAddItemToBag());

		JavascriptExecutor jse2 = (JavascriptExecutor) getDriver();
		jse2.executeScript("arguments[0].click();", getbtnAddItemToBag());
		pause(7000);

		WaitForElementPresent(getbtnCart());
		getbtnCart().click();

		WaitForElementPresent(getbtncheckout());
		getbtncheckout().click();

		WaitForElementPresent(getrbnPickUp());
		jse2.executeScript("arguments[0].click();", getrbnPickUp());
		pause(5000);

		jse2.executeScript("arguments[0].scrollIntoView()", gettxtzipcode());
		WaitForElementPresent(gettxtCardHolderName());
		gettxtCardHolderName().sendKeys(getProperty("CardHolderName"));
		gettxtCreditcardNumber().sendKeys(getProperty("CardNumber"));
		gettxtExpiryDate().sendKeys("12 / 2022");
		gettxtCvv().sendKeys(getProperty("CVV"));
		gettxtzipcode().sendKeys(getProperty("Zipcode"));

		jse2.executeScript("arguments[0].click();", getbtnPlaceOrder());
		pause(10000);
		WaitForElementPresent(getimgSiteLogo());
		WaitForElementClickable(getbtnMenu());
		getbtnMenu().click();

	}
}
