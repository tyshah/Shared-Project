package com.cipl.tests;

import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;

import com.cipl.pages.OrderPage;

public class OrderTest extends OrderPage {

	@Test(priority = 1, description = "Take 20 orders using loop")
	public void Tc1() {
		WaitForElementPresent(getbtnJoinUser());
		getbtnJoinUser().click();
		doLogin(getProperty("UserName"), getProperty("Password"));

		for (int i = 0; i < 20; i++) {
			placeOrder();
		}

	}

	@AfterSuite
	public void teardown() {
		if (getDriver() != null) {
			getDriver().quit();
		}
	}

}
