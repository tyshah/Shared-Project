package com.cipl.driver;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestBase {
	public WebDriver driver;
	public WebDriverWait wait;

	public WebDriver getDriver() {
		if (driver != null) {
			return driver;
		} else {
			SetDriver();
			return driver;
		}
	}
	
	private void SetDriver() {
		String strBrowserType = getProperty("browser");

		switch (strBrowserType) {
		case "chrome":
			driver = intichromeDriver();
			break;
		case "firefox":
			driver = initFirefoxDriver();
			break;
		default:
			System.out.println(
					"Default browser type is not provided in base.properties so that by choice chrome driver is opening...");

			driver = intichromeDriver();
			break;

		}
	}

	public WebDriver intichromeDriver() {
		System.setProperty("webdriver.chrome.driver", "resources\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(getProperty("BASE_URL"));
		pause(13000);
		return driver;
	}

	public WebDriver initFirefoxDriver() {
		System.setProperty("webdriver.chrome.driver", "resources\\geckodriver.exe");
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		driver.get(getProperty("BASE_URL"));
		pause(3000);
		return driver;
	}

	public void pause(int millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static String getProperty(String strKey) {
		try {
			InputStream input;

			input = new FileInputStream(new File("resources\\base.properties"));
			Properties prop = new Properties();
			prop.load(input);

			return prop.getProperty(strKey);

		} catch (Exception ex) {
			ex.printStackTrace();
			return "";
		}
	}

	public void WaitForElementPresent(WebElement element) {
		int timeout = Integer.parseInt(getProperty("timeout"));
		WebDriverWait wait = new WebDriverWait(getDriver(), timeout);		
		wait.until(ExpectedConditions.visibilityOf(element));
	}
	
	public void WaitForElementClickable(WebElement element) {
		int timeout = Integer.parseInt(getProperty("timeout"));
		WebDriverWait wait = new WebDriverWait(getDriver(), timeout);		
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	

	public static void VerifyPresent(WebElement element, String strElementName) {
		if (element.isDisplayed() == true) {
			System.out.println(
					"Expected : " + strElementName + " should be present. Actual : " + strElementName + " is present.");
		} else {
			System.out.println("Expected : " + strElementName + " should be present. Actual : " + strElementName
					+ " is not present.");
		}
	}
}
